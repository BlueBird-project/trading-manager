import logging
import time
from typing import List

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("debug.log"),
        logging.StreamHandler()
    ]
)
if __name__ == "__main__":
    ###
    # setup configurations
    ###

    logging.info(f"START SAMPLE CLIENT")

if __name__ == "__main__":
    logging.info("INIT KI")
    # setup ke
    import ke_client.ke_vars as ke_vars

    ke_vars.VERIFY_SERVER_CERT = False
    ke_vars.ENV_FILE = ".env.tm"
    from ke_client import configure_ke_client

    configure_ke_client(yml_config_path="src/config_files/tm_app_config.yml")

    from src.interactions import set_tm_client

    set_tm_client()
    # set_tm_client(blocking=True)

    # from src.interactions.tm_interactions import *

if __name__ == "__main__":
    from src.interactions.tm_interactions import request_ts_info, request_data
    from ke_client.ki_model import KIPostResponse

    from src.interactions.ki_models import FMTSResponse

    while True:
        print("tick")
        try:
            print("request  flexibility info")
            r: List[FMTSResponse] = request_ts_info()
            print("received  flexibility info")
            print([uri.ts_uri for uri in r])
            # raw_bindings= r.result_binding_set
            uris = [ts_uri.ts_uri for ts_uri in r]
            print("get flex data:")
            data = request_data(ts_uris=uris)
            for d in data:
                print(f"{d.ts}: {d.value}")
        except Exception as ex:
            print(ex)

        time.sleep(30)
        print("tock")
