KE_REST_ENDPOINT=http://localhost:8280/rest/
KE_KNOWLEDGE_BASE_ID=http://tm.test.bluebird.com
APP_KI_CONFIG_PATH=./tm_test.yml











