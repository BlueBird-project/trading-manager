from datetime import datetime as dt, tzinfo, timezone
from typing import Optional

import pytz

DAY_MS = 24 * 3600 * 1000
WEEK_MS = 7 * DAY_MS


def xsd_from_ts(ts: int, tz=pytz.utc) -> str:
    # tz=pytz.timezone('Europe/Paris')
    return dt.fromtimestamp(float(ts) / 1000.0, tz=tz).isoformat()


def xsd_to_ts(xsd_dt: str) -> int:
    return round(dt.fromisoformat(xsd_dt).timestamp() * 1000)


def current_timestamp() -> int:
    now_utc = dt.now(timezone.utc)
    return int(now_utc.timestamp() * 1000)


def xsd_now(tz=pytz.utc):
    # tz=pytz.timezone('Europe/Paris')
    return xsd_from_ts(current_timestamp(), tz=tz)


class TimeSpan:
    ts_from: Optional[int] = None
    ts_to: Optional[int] = None

    def __init__(self, ts_from: Optional[int] = None, ts_to: Optional[int] = None):
        if ts_from is None and ts_to is None:
            from effi_onto_tools.utils import time_utils
            ts_to = time_utils.current_timestamp()
        self.ts_from = ts_from if ts_from is not None else ts_to - DAY_MS
        self.ts_to = ts_to if ts_to is not None else ts_from + DAY_MS
        if self.ts_to < self.ts_from:
            raise ValueError("Time from cannot be after time to")

    @staticmethod
    def last_week():
        from effi_onto_tools.utils import time_utils
        ts_to = time_utils.current_timestamp()
        ts_from = ts_to - WEEK_MS
        return TimeSpan(ts_from=ts_from, ts_to=ts_to)

    @staticmethod
    def last_day():
        from effi_onto_tools.utils import time_utils
        ts_to = time_utils.current_timestamp()
        ts_from = ts_to - DAY_MS
        return TimeSpan(ts_from=ts_from, ts_to=ts_to)
