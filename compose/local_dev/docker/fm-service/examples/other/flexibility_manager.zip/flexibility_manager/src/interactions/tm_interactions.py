import logging
import random
from typing import Union, List, Optional
from isodate import parse_duration
from ke_client import KEClient

from ke_client.ki_model import KIPostResponse, KIAskResponse
from rdflib import URIRef, Literal

from .ki_models import FMTSResponse, FMTSRequest, FMTSSplitURI, DPSplitURI, FMEvaluateQuery, FMPntQuery, FMPnt, \
    TOUPriceInfo, TOUPriceInfoSimpleQuery, TOUPriceInfoQuery, TOUPrice, FMEvaluateResponse, TOUSplitURI, TOURangeURI, \
    TOURangeMaxURI, TOURangeMinURI, TOUPriceQuery, OfferDPSplitURI, KETimeIntervalUri
from ..utils import xsd_to_ts, xsd_now, current_timestamp, xsd_from_ts, TimeSpan

ki_client = KEClient.build(logger=logging.getLogger())

SAMPLE_POWER_RANGE_ID = 5

ISP_UNIT_MINUTES = 60


#


@ki_client.post("fm-ts-info-request")
def _request_market_info(request: FMTSRequest):
    request_bindings = request.n3()
    return [request_bindings]


@ki_client.ask("fm-ts")
def _request_data(ts_uris: List[FMPntQuery]):
    ask_bindings = [ts_uri.n3() for ts_uri in ts_uris]
    return ask_bindings


def evaluate(query: List[FMEvaluateQuery]) -> List[FMEvaluateResponse]:
    response = []
    for q in query:
        ts_uri: FMTSSplitURI = FMTSSplitURI.parse(q.ts_uri)
        dp_uri = DPSplitURI.parse(q.dp)
        ts = xsd_to_ts(q.ts)
        value: float = q.convert_value(q.value, float)
        # //TODO: evaluate power cost

        # tou_uri = tou_model.TOUSplitURI(range_id=range_id, period_minutes=ts_uri.period_minutes, ts=ts)
        # tou_price = FMEvaluateResponse(dp=dp_uri.uri_ref, cost_dpr=URIRef(dp_uri.uri + "/dpr"), cost=rdf_nil)
        tou_price = FMEvaluateResponse(dp=dp_uri.uri_ref, cost_dpr=URIRef(dp_uri.uri + "/dpr"), cost=Literal(0.5*value))

        response.append(tou_price)

    return response


# noinspection PyUnusedLocal
@ki_client.react("fm-ts-evaluate")
def _on_evaluate_request(ki_id, bindings):
    q = [FMEvaluateQuery(**b) for b in bindings]
    bindings = [b.n3() for b in evaluate(q)]
    return bindings


def get_range_tou(binding_query: List[Union[TOUPriceInfoQuery, TOUPriceInfoSimpleQuery]]) -> \
        List[TOUPriceInfo]:
    # TODO: we support only one first binding query
    for q in binding_query:
        ts_from = xsd_to_ts(q.time_create.value)
        # time_span_ms =  from_n3(KIVars.DAY_DURATION)
        time_span_ms = int(parse_duration(q.tou_period, as_timedelta_if_possible=True).total_seconds() * 1000)
        if type(q) is TOUPriceInfoSimpleQuery:
            tou_uriref = TOUSplitURI(range_id=SAMPLE_POWER_RANGE_ID, period_minutes=time_span_ms / 60000,
                                     ts=ts_from).uri_ref
            return [TOUPriceInfo(**{**q.input_bindings, **{"tou_uri": tou_uriref}})]

        min_val, max_val = q.get_power_limit()

        max_value = 5000
        min_value = None

        def init_range():
            power_range = TOURangeURI(range_id=SAMPLE_POWER_RANGE_ID).n3()
            range_max = TOURangeMaxURI(range_id=SAMPLE_POWER_RANGE_ID).n3()
            range_min = TOURangeMinURI(range_id=SAMPLE_POWER_RANGE_ID).n3()
            tou_uri = TOUSplitURI(range_id=SAMPLE_POWER_RANGE_ID, period_minutes=time_span_ms / 60000, ts=ts_from).n3()
            ri_max_val = max_value if max_value is not None else URIRef("rdf:nil")
            ri_min_val = min_value if min_value is not None else URIRef("rdf:nil")

            return {"tou_uri": tou_uri, "power_range": power_range, "max_value": ri_max_val, "min_value": ri_min_val,
                    "power_range_min": range_min, "power_range_max": range_max}

        price_info = [
            TOUPriceInfo(**{**init_range(), **q.input_bindings})
        ]

        return price_info


@ki_client.answer("tou-price-info",
                  args=["time_create", "tou_period", "min_value", "power_range", "max_value"])
def on_price_info_request(ki_id: str, bindings: list[dict]):
    tou_bindings = [TOUPriceInfoQuery(**b) if "power_range" not in b else TOUPriceInfoSimpleQuery(**b) for b in
                    bindings]
    prince_info_resp = get_range_tou(tou_bindings)
    answer_bindings = [p.n3() for p in prince_info_resp]
    # print(answer_bindings)
    return answer_bindings


def get_price(binding_query: List[TOUPriceQuery]) -> List[TOUPrice]:
    for q in binding_query:
        split_uri = TOUSplitURI.parse(q.tou_uri)
        # dp_uri = DPSplitURI.parse(q.dp)
        ts_start = split_uri.ts
        isp_span = int(split_uri.period_minutes / ISP_UNIT_MINUTES) + 1

        def init_dp(isp):
            tou_uri = q.tou_uri
            dp_uri = OfferDPSplitURI(range_id=SAMPLE_POWER_RANGE_ID, period_minutes=ISP_UNIT_MINUTES,
                                     offer_id=current_timestamp(),
                                     isp_start=isp).uri
            return TOUPrice(tou_uri=tou_uri, dp=URIRef(dp_uri),
                            ts=Literal(xsd_from_ts(ts_start + 1000 * ISP_UNIT_MINUTES * isp)),
                            dpr=URIRef(dp_uri + "/dpr"),
                            value=150)

        return [init_dp(i) for i in range(0, isp_span)]

    return []


@ki_client.answer("tou-price", args=["tou_uri"])
def on_price_request(ki_id: str, bindings: list[dict]):
    # print("on_price_request")
    tou_bindings = [TOUPriceQuery(**b) for b in bindings]
    hour_ms = 3600000
    current_ts = int(current_timestamp() / hour_ms) * hour_ms
    ts_end = current_ts + 24 * hour_ms
    price_resp = get_price(tou_bindings)
    return [p.n3() for p in price_resp]


def request_ts_info() -> List[FMTSResponse]:
    ts_start = current_timestamp() - 3600000 * 12
    ts_end = ts_start + 3600000 * 12
    # noinspection PyTypeChecker
    resp_bindings: KIPostResponse = _request_market_info(FMTSRequest(
        ts_interval_uri=KETimeIntervalUri(ts_from=ts_start, ts_to=ts_end).n3(),
        ts_date_from=Literal(xsd_from_ts(ts_start)),
        ts_date_to=Literal(xsd_from_ts(ts_end)),
    ))
    return [FMTSResponse(**b) for b in resp_bindings.resultBindingSet]


def request_data(ts_uris: List[str]) -> List[FMPnt]:
    ts_uri_refs = [FMPntQuery(ts_uri=URIRef(ts_uri)) for ts_uri in ts_uris]
    # noinspection PyTypeChecker
    bindings: KIAskResponse = _request_data(ts_uris=ts_uri_refs)
    return [FMPnt(**b) for b in bindings.bindingSet]
