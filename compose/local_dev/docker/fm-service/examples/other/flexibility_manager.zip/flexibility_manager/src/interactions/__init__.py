import logging
import time

from ke_client import KEClient


def _set_ke_client(ke_ki_client, bg_mode=False):
    def try_register():
        ke_ki_client.register()
        timeout_attempt = 0
        is_registered = False
        while not is_registered:
            time.sleep(1)
            is_registered = ke_ki_client.is_registered
            if is_registered:
                logging.info("KE client registered")
            else:
                logging.warning(f"KE client is not registered, wait for all KI to be registered.")
                time.sleep(10)
            if timeout_attempt > 10:
                raise TimeoutError("Registration timeout")
            else:
                timeout_attempt += 1

    def try_bg_register():
        try_register()
        ke_ki_client.start()

    if bg_mode:
        import threading
        # background start

        t = threading.Thread(target=try_bg_register)
        t.start()

    else:
        try_register()
        ke_ki_client.start_sync()


# def set_bg_ke_client():
#     # background client
#     from .fm_interactions import ki_client
#     _set_ke_client(ki_client, bg_mode=True)
#     while not ki_client.is_registered:
#         print("wait for registration")
#         time.sleep(4)
#
#
# def set_sync_ke_client():
#     # blocking client
#     from .fm_interactions import ki_client
#     _set_ke_client(ki_client, bg_mode=False)


def set_fm_client(blocking_client=False):
    from .fm_interactions import ki_client
    _set_ke_client(ki_client, bg_mode=not blocking_client)


def set_tm_client(blocking_client=False):
    from .tm_interactions import ki_client
    _set_ke_client(ki_client, bg_mode=not blocking_client)
