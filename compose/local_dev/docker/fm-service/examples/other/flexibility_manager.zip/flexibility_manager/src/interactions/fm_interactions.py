import logging
import random
from typing import Union, List, Optional

from ke_client import KEClient
from ke_client.ki_model import KIAskResponse
from rdflib import URIRef, Literal

from .ki_models import FMTSResponse, FMTSRequest, FMTSSplitURI, DPSplitURI, FMEvaluateQuery, FMPntQuery, FMPnt, \
    TOUPriceInfo, TOUPriceInfoSimpleQuery, TOUPriceInfoQuery, TOUPrice
from ..utils import xsd_to_ts, xsd_now, current_timestamp, xsd_from_ts, TimeSpan

ki_client = KEClient.build(logger=logging.getLogger())


#
@ki_client.react("fm-ts-info-request", response_class=FMTSResponse)
def on_request_ts_info(ki_id, bindings):
    """
    reply with timeseries URI
    :param ki_id:
    :param bindings:
    :return:
    """
    print(f"react fm-ts-info-request, input {bindings}")
    for b in bindings:
        #     TODO: support only one request
        request = FMTSRequest(**b)
        ts_from: int = xsd_to_ts(request.ts_date_from.value)
        ts_to = xsd_to_ts(request.ts_date_to.value)

        # determine the meaning of data points

        ts_usage = URIRef("s4ener:Consumption")
        ts_usage2 = URIRef("s4ener:Production")
        ts_uri2 = FMTSSplitURI(ts_from=ts_from, ts_to=ts_to, period_minutes=60, ts_usage=ts_usage2).n3()
        ts_uri = FMTSSplitURI(ts_from=ts_from, ts_to=ts_to, period_minutes=60, ts_usage=ts_usage).n3()
        time_create = Literal(xsd_now())
        return [
            FMTSResponse(ts_uri=ts_uri, ts_interval_uri=request.ts_interval_uri, ts_usage=ts_usage,
                         time_create=time_create).n3(),
            FMTSResponse(ts_uri=ts_uri2, ts_interval_uri=request.ts_interval_uri, ts_usage=ts_usage2,
                         time_create=time_create).n3()
        ]


@ki_client.post("fm-ts-evaluate")
def evaluate_request():
    # Get prices for energy data timeseries
    hour_ms = 3600000
    current_ts = int(current_timestamp() / hour_ms) * hour_ms
    ts_end = current_ts + 24 * hour_ms
    ts_usage = URIRef("s4ener:Consumption")
    # ts_usage2 = URIRef("s4ener:Production")
    ts_uri = FMTSSplitURI(ts_from=current_ts, ts_to=ts_end, period_minutes=60, ts_usage=ts_usage)
    response = []
    # generate random usage timeseries
    for i in range(0, 24):
        ts = i * hour_ms + current_ts
        xsd_ts = xsd_from_ts(ts)
        dp_uri = DPSplitURI(ts_start=ts, ts_usage=FMTSSplitURI.convert_ts_usage(ts_usage), isp_start=i)
        dpr_uri_ref = URIRef(dp_uri.uri + "/dpr")
        value = Literal(random.randrange(400, 1200))
        response.append(FMEvaluateQuery(ts_uri=ts_uri.uri_ref, dp=dp_uri.uri_ref, ts=Literal(xsd_ts), dpr=dpr_uri_ref,
                                        value=value).n3())
    return response


@ki_client.answer("fm-ts", args=["ts_uri"])
def on_fm_request(ki_id: str, bindings: list[dict]):
    # return flexibility timeseries points
    print("on_fm_request")
    print(bindings)
    ts_bindings = [FMPntQuery(**b) for b in bindings]
    for ts_binding in ts_bindings:
        ts_uri = ts_binding.ts_uri
        parsed_uri = FMTSSplitURI.parse(ts_uri)
        ts_resp = [FMPnt(ts_uri=ts_uri,
                         dp=
                         DPSplitURI(ts_start=parsed_uri.ts_to, ts_usage=parsed_uri.ts_usage, isp_start=i).n3(),
                         ts=Literal(xsd_from_ts(parsed_uri.ts_from + 60 * 1000)),
                         dpr=URIRef(
                             DPSplitURI(ts_start=parsed_uri.ts_to, ts_usage=parsed_uri.ts_usage,
                                        isp_start=i).uri + "/dpr"),
                         value=random.random() * 200 + 50) for i in range(1, 24)]

        answer_bindings = [p.n3() for p in ts_resp]
        print(answer_bindings)
        return answer_bindings


#
# @ki_client.ask("tou-general-price-info-fm", args=["time_create", "tou_period"])
# def _get_price_general_info(time_create: Literal, tou_period: Literal):
#     ask_bindings = [{"time_create": time_create.n3(), "tou_period": tou_period.n3()}]
#     return ask_bindings


@ki_client.ask("tou-price", args=["tou_uri"])
def _get_tou_price(tou_uris: List[URIRef]):
    ask_bindings = [{"tou_uri": tou_uri.n3()} for tou_uri in tou_uris]
    print(ask_bindings)
    return ask_bindings


@ki_client.ask("tou-price-info",
               args=["time_create", "tou_period", "min_value", "max_value", "power_range"])
def _get_price_info(query: Union[TOUPriceInfoSimpleQuery, TOUPriceInfoQuery]):
    query_bindings = query.n3()
    print("query: ")
    print(query_bindings)
    return [query_bindings]


def get_tou(ts: TimeSpan) -> list[TOUPriceInfo]:
    """
    get price timeseries
    :param ts:
    :return:
    """
    iso_duration = f"PT{int((ts.ts_to - ts.ts_from) / 60000)}M"
    q = TOUPriceInfoSimpleQuery(time_create=Literal(xsd_from_ts(ts.ts_from)),
                                tou_period=Literal(lexical_or_value=iso_duration, datatype="xsd:duration"))
    price_info_response: KIAskResponse = _get_price_info(query=q)
    return [TOUPriceInfo(**b) for b in price_info_response.binding_set]


def get_tiered_tou(ts: TimeSpan, min_value: Optional[float], max_value: Optional[float] = None) -> list[TOUPriceInfo]:
    iso_duration = f"PT{int((ts.ts_to - ts.ts_from) / 60000)}M"
    q = TOUPriceInfoQuery(time_create=Literal(xsd_from_ts(ts.ts_from)),
                          tou_period=Literal(lexical_or_value=iso_duration, datatype="xsd:duration"),
                          min_value=Literal(min_value) if min_value is not None else None,
                          max_value=Literal(max_value) if max_value is not None else None)
    price_info_bindings = _get_price_info(query=q)
    return [TOUPriceInfo(**b) for b in price_info_bindings]


def get_tou_price(tou_uris: List[str]) -> List[TOUPrice]:
    tou_urisrefs = [URIRef(tou_uri) for tou_uri in tou_uris]
    bindings: KIAskResponse = _get_tou_price(tou_uris=tou_urisrefs)
    return [TOUPrice(**b) for b in bindings.bindingSet]
