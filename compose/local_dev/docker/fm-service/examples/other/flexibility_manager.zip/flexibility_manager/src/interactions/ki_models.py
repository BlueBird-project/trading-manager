from typing import Optional, Tuple, Union, Any

from ke_client import BindingsBase, rdf_nil, ke_settings

from ke_client import ki_object, SplitURIBase, ki_split_uri
from rdflib import URIRef, Literal

from src.utils import xsd_to_ts

# TODO sprawdzic uri
FM_URI = "http://fm.test.bluebird.com"
TM_URI = "http://tm.test.bluebird.com"


# region exchange binding objects
@ki_object("fm-ts-info-request")
class FMTSRequest(BindingsBase):
    ts_interval_uri: URIRef
    ts_date_from: Literal
    ts_date_to: Literal

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


@ki_object("fm-ts-info-request", result=True)
class FMTSResponse(BindingsBase):
    ts_uri: URIRef
    ts_interval_uri: URIRef
    # ts_usage: Union[Literal, URIRef]
    ts_usage: URIRef
    time_create: Literal

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


@ki_object("fm-ts-evaluate")
class FMEvaluateQuery(BindingsBase):
    ts_uri: URIRef
    dp: URIRef
    ts: Literal
    dpr: URIRef
    value: Literal

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


@ki_object("fm-ts", allow_partial=True)
class FMPntQuery(BindingsBase):
    ts_uri: URIRef

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


@ki_object("fm-ts")
class FMPnt(BindingsBase):
    ts_uri: URIRef
    dp: URIRef
    ts: Literal
    dpr: URIRef
    value: Optional[Literal]

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)

    @property
    def ts_ms(self) -> int:
        return xsd_to_ts(self.ts)

    def get_value(self) -> Optional[float]:
        return self.convert_value(self.value, float)


@ki_object("tou-price-info")
class TOUPriceInfo(BindingsBase):
    tou_uri: URIRef
    time_create: Literal
    tou_period: Literal
    power_range: URIRef
    power_range_max: URIRef = rdf_nil
    max_value: Union[Literal, URIRef] = rdf_nil
    power_range_min: URIRef = rdf_nil
    min_value: Union[Literal, URIRef] = rdf_nil

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)

    def get_power_limit(self) -> Tuple[float, float]:
        min_value = float(self.min_value) if self.min_value is not None else None
        max_value = float(self.max_value) if self.max_value is not None else None
        return min_value, max_value


@ki_object("tou-price-info", allow_partial=True)
class TOUPriceInfoSimpleQuery(BindingsBase):
    time_create: Literal
    tou_period: Literal
    power_range: URIRef = rdf_nil

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


#
#
# @ki_object("tou-price-info", allow_partial=True)
# class TOUPriceInfoSimpleResponse(BindingsBase):
#     tou_uri: URIRef
#
#     def __init__(self, **kwargs):
#         super().__init__(bindings=kwargs)
#
#
@ki_object("tou-price-info", allow_partial=True)
class TOUPriceInfoQuery(BindingsBase):
    time_create: Literal
    tou_period: Literal
    max_value: Union[Literal, URIRef, None] = None
    min_value: Union[Literal, URIRef, None] = None

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)

    def get_power_limit(self) -> Tuple[float, float]:
        min_value = float(self.min_value) if self.min_value is not None else None
        max_value = float(self.max_value) if self.max_value is not None else None
        return min_value, max_value


@ki_object("tou-price")
class TOUPrice(BindingsBase):
    tou_uri: URIRef
    dp: URIRef
    ts: Literal
    dpr: URIRef
    value: Union[Literal, URIRef, None]

    def __init__(self, **kwargs):
        if "value" not in kwargs:
            kwargs["value"] = rdf_nil
        super().__init__(bindings=kwargs)


@ki_object("fm-ts-evaluate", result=True)
class FMEvaluateResponse(BindingsBase):
    dp: URIRef
    cost_dpr: URIRef
    cost: Union[Literal, URIRef]

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


#
# @ki_object("tou-price-info")
# class TOUPriceInfo(BindingsBase):
#     tou_uri: URIRef
#     time_create: Literal
#     tou_period: Literal
#     power_range: URIRef
#     power_range_max: URIRef = rdf_nil
#     max_value: Union[Literal, URIRef] = rdf_nil
#     power_range_min: URIRef = rdf_nil
#     min_value: Union[Literal, URIRef] = rdf_nil
#
#     def __init__(self, **kwargs):
#         super().__init__(bindings=kwargs)
#
#     def get_power_limit(self) -> Tuple[float, float]:
#         min_value = float(self.min_value) if self.min_value is not None else None
#         max_value = float(self.max_value) if self.max_value is not None else None
#         return min_value, max_value
#
#

#
#     @property
#     def ts_ms(self) -> int:
#         return xsd_to_ts(self.ts)
#
#     def get_value(self) -> Optional[float]:
#         return self.convert_value(self.value, float)
#
#
@ki_object("tou-price", allow_partial=True)
class TOUPriceQuery(BindingsBase):
    tou_uri: URIRef

    def __init__(self, **kwargs):
        super().__init__(bindings=kwargs)


# endregion

# region uris
@ki_split_uri(uri_template=f"{FM_URI}/ts" + "/${ts_from}/${ts_to}/${period_minutes}/${ts_usage}")
class FMTSSplitURI(SplitURIBase):
    ts_from: int
    ts_to: int
    period_minutes: int
    ts_usage: int

    def __init__(self, /, ts_usage: Union[URIRef, int], **data: Any):
        if type(ts_usage) is URIRef:
            ts_usage = FMTSSplitURI.convert_ts_usage(ts_usage)
        super().__init__(ts_usage=ts_usage, **data)

    @staticmethod
    def convert_ts_usage(ts_usage_uri_ref: URIRef):
        uri_fragment: str = ts_usage_uri_ref.defrag().lower()
        #  s4ener:Consumption, s4ener:Downflex,   s4ener:Production,  s4ener:Upflex
        if "Consumption".lower() in uri_fragment:
            return 0
        if "Downflex".lower() in uri_fragment:
            # Downward flexibility (DOWN-flex): The ability to increase consumption or decrease generation
            # to absorb excess energy in the system.
            return 1
        if "Production".lower() in uri_fragment:
            return 2
        if "Upflex".lower() in uri_fragment:
            # Upward flexibility (UP-flex): The ability to decrease consumption or increase generation to
            # meet high demand or low supply conditions.
            return 3


@ki_split_uri(uri_template=f"{FM_URI}/dp" + "/${ts_start}/${isp_start}/${ts_usage}")
class DPSplitURI(SplitURIBase):
    ts_start: int
    ts_usage: int
    isp_start: int


@ki_split_uri(uri_template=f"{TM_URI}/dp" + "/${ts_start}/${isp_start}/${ts_usage}")
class TMDPSplitURI(SplitURIBase):
    ts_start: int
    ts_usage: int
    isp_start: int


@ki_split_uri(uri_template=f"{TM_URI}/tou" + "/${range_id}/${period_minutes}/${ts}")
class TOUSplitURI(SplitURIBase):
    range_id: int
    period_minutes: int
    ts: int


@ki_split_uri(uri_template=f"{TM_URI}/tou_range" + "/${range_id}")
class TOURangeURI(SplitURIBase):
    range_id: int


@ki_split_uri(uri_template=f"{TM_URI}/tou_range_max" + "/${range_id}")
class TOURangeMaxURI(SplitURIBase):
    range_id: int


@ki_split_uri(uri_template=f"{TM_URI}/tou_range_min" + "/${range_id}")
class TOURangeMinURI(SplitURIBase):
    range_id: int


@ki_split_uri(
    uri_template=f"{TM_URI}/offer" + "/${offer_id}/${range_id}/${period_minutes}/${isp_start}")
class OfferDPSplitURI(SplitURIBase):
    range_id: int
    period_minutes: int
    offer_id: int
    isp_start: int


@ki_split_uri(uri_template="http://ke.bluebird.com/interval/${ts_from}/${ts_to}")
class KETimeIntervalUri(SplitURIBase):
    ts_from: int
    ts_to: int
#
#
# @ki_split_uri(uri_template=f"{ke_settings.knowledge_base_id}/offer" + "/${range_id}/${period_minutes}/${isp_start}")
# class TOUDPSplitURI(SplitURIBase):
#     range_id: int
#     period_minutes: int
#     isp_start: int
#
#

#
#

#
#


# endregion

#
# from typing import Optional, Union, Any
#
# from ke_client import ki_split_uri, SplitURIBase, BindingsBase, ki_object
# from effi_onto_tools.utils import time_utils
# from rdflib import URIRef, Literal
#
#

#
#

#
#

#
#

#

#
#

#
#

#
#
# @ki_split_uri(uri_template="http://ke.bluebird.com/interval/${ts_from}/${ts_to}")
# class KETimeIntervalUri(SplitURIBase):
#     ts_from: int
#     ts_to: int
#
#

#
#     @staticmethod
#     def parse_usage(usage_id: int):
#         if 0 == usage_id:
#             return URIRef("s4ener:Consumption")
#         if 1 == usage_id:
#             return URIRef("s4ener:Downflex")
#         if 2 == usage_id:
#             return URIRef("s4ener:Production")
#         if 3 == usage_id:
#             return URIRef("s4ener:Upflex")
