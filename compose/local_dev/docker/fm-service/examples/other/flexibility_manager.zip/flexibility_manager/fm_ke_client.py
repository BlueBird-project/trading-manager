import logging
import time
from typing import List, Optional

from ke_client.ki_model import KIPostResponse
from rdflib import URIRef

from src.utils import TimeSpan

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("debug.log"),
        logging.StreamHandler()
    ]
)
if __name__ == "__main__":
    ###
    # setup configurations
    ###

    logging.info(f"START SAMPLE CLIENT")

if __name__ == "__main__":
    logging.info("INIT KI")
    # setup ke
    import ke_client.ke_vars as ke_vars

    ke_vars.VERIFY_SERVER_CERT = False
    ke_vars.ENV_FILE = ".env"
    from ke_client import configure_ke_client

    configure_ke_client(yml_config_path="src/config_files/app_config.yml")

    from src.interactions import set_fm_client

    set_fm_client()
    # set_fm_client(blocking=True)

    from src.interactions.fm_interactions import evaluate_request, get_tou, get_tou_price
    from src.interactions.ki_models import TOUPriceInfo, FMEvaluateResponse

    tou_uri_list: Optional[List[TOUPriceInfo]] = None
    tou_dp = None


if __name__ == "__main__":
    while True:
        try:
            print("request prices for flexibility")
            r: KIPostResponse = evaluate_request()
            print("received prices for flexibility")
            # raw_bindings= r.result_binding_set
            for price in [FMEvaluateResponse(**dp) for dp in r.result_binding_set]:
                print(f"dp:{str(price.dp)} = {price.cost.value}")
            print(r)
        except Exception as ex:
            print(ex)
        ####
        tou_uri_list: List[TOUPriceInfo] = []
        try:
            print("get tou uri refs")
            tou_uri_list: List[TOUPriceInfo] = get_tou(ts=TimeSpan(1765002982000, 1765325147000))
            print("Received tou uri refs")
            for tou_info in tou_uri_list:
                print(tou_info.n3())
        except Exception as ex:
            print(ex)
            time.sleep(10)

        print("tick")
        time.sleep(30)
        print("tock")
